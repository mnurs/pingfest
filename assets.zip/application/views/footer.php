</div>
            </div>
            <div class="bg-dark text-white p-2">
                <p class="text-center">Copyright &copy; 2022, HIMASTER UNS</p>
            </div>
        </div>
    </body>
</html>