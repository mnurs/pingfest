<form action="<?php echo site_url('profile/fake_login'); ?>" method="post">
    <div><input type="text" class="form-control" name="user_id" placeholder="User ID"></div>
    <div><button type="submit" class="btn btn-success" name="submit" value="1">Login!</button></div>
</form>
