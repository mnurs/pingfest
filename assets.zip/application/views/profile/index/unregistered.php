<div class="container">
    <div class="row">
        <div class="col-12 text-center" style="padding-top: 3rem; padding-bottom: 3rem">
            <span class="my-4 display-1 fa fa-ban"></span>
            <h3>Tidak Terdaftar</h3>
            <span>Anda tidak terdaftar dalam event ini. Silakan untuk melakukan pendaftaran dengan <a href="<?php echo site_url('profile/index').'?tab=registration#invoice-'.md5($event); ?>">klik di sini</a></span>
        </div>
    </div>
</div>
