<div class="container">
    <div class="row">
        <div class="col-12 text-center" style="padding-top: 3rem; padding-bottom: 3rem">
            <span class="my-4 display-1 fa fa-check"></span>
            <h3>Terdaftar</h3>
            <span>Anda telah terdaftar dalam event ini. Silakan untuk melengkapi identitas anda dengan mengklik tombol di bawah</span>
            <p><a class="btn btn-primary identitas" href="<?php echo site_url('profile/setup').'?event='.urlencode($event); ?>">Lengkapi Identitas</a></p>
        </div>
    </div>
</div>
